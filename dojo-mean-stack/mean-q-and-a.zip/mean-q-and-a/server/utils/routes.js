const users = require('./../controllers/users.js');
const questions = require('./../controllers/questions.js')
const answers = require('./../controllers/answers.js')
const {resolve} = require('path');
module.exports = function (app) {
	//Set up routes
	// Index route
	app.post('/api/users', users.login);

	app.post('/api/questions', questions.create);

	app.post('/api/answers/:id', answers.create);

	app.post('/api/questions/:id', questions.update);

	app.get('/api/questions', questions.show);

	app.get('/api/questions/:id', questions.showOne);

	app.all("*", (req, res, next) => {
		res.sendfile(resolve("./public/dist/index.html"));
	})

};
