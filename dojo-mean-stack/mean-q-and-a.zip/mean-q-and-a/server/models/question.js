'use strict';
const mongoose = require('mongoose');

const QuestionSchema = new mongoose.Schema({
    question: { type: String, required: [true, 'Question is required!'], minlength: [10, 'Question should be at least 2 characters!']},
    description: { type: String },
	answers: []
})
const Question = mongoose.model('Question', QuestionSchema)
