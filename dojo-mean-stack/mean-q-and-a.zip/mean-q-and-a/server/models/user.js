'use strict';
const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
	name: { type: String, required: [true, 'Name is required!'], minlength: [2, 'Name should be at least 2 characters!']},
	questions: []
})
const User = mongoose.model('User', UserSchema)
