'use strict';
const mongoose = require('mongoose');

const AnswerSchema = new mongoose.Schema({
    answer: { type: String, required: [true, 'Answer is required!'], minlength: [4, 'Answer should be at least 4 characters!']},
    details: { type: String },
    name: { type: String, required: [true, 'Name should be defaulted, are you logged in correctly?']},
    likes: { type: Number, default: 0 }
})
const Answer = mongoose.model('Answer', AnswerSchema)
