const mongoose = require('mongoose');
const User = mongoose.model('User');
const Question = mongoose.model('Question');
const session = require('express-session')

module.exports = {
	// login: (req, res) => {
	// 	User.findOne({name: req.body.name})
	// 		.then(user => {
	// 			if(user){
	// 				session.user = user
	// 				console.log(session.user)
	// 				res.json(user)
	// 			} else {
	// 				let new_user = new User(req.body)
	// 				console.log(new_user)
	// 				new_user.save()
	// 					.then(() => {
	// 						session.user = new_user
	// 						res.json(user)
	// 					})
	// 					.catch(err => {
	// 						console.log('error', err)
	// 						res.status(500).json(err)
	// 					})
	// 			}
	// 		})
	// }
	update: (req, res) => {
		console.log(req.body)
		console.log(req.params.id)
		let index = req.body.ind
		console.log(index)
		Question.find({_id: req.params.id})
			.then((question) => {
				// console.log('*****')
				// console.log(question)
				// question[0].answers[req.body.ind] = req.body
				// console.log('****')
				// console.log(question[0].answers)
				// res.json(question)
			})
			.catch(err => res.status(400).json(err))
	},

	showOne: (req, res) => {
		console.log(req.body)
		Question.findById({_id: req.params.id})
			.then(question => res.json(question))
	},
	show: (req, res) => {
		Question.find({})
			.then(questions => res.json(questions))
			.catch(err => res.status(500).json(err))
	},
    create: (req, res) => {
        User.findById({_id: session.user._id}, (err, user) => {
            if (err) {
                res.status(500).json(err)
            } else {
				let question = new Question(req.body)
				question.save()
					.then(() => res.json(question))
					.catch(err => res.status(500).json(err))
            }
        })
    }
}
