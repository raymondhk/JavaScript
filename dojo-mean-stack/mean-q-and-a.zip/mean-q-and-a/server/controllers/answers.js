const mongoose = require('mongoose');
const User = mongoose.model('User');
const Question = mongoose.model('Question');
const Answer = mongoose.model('Answer');
const session = require('express-session')

module.exports = {
	// login: (req, res) => {
	// 	User.findOne({name: req.body.name})
	// 		.then(user => {
	// 			if(user){
	// 				session.user = user
	// 				console.log(session.user)
	// 				res.json(user)
	// 			} else {
	// 				let new_user = new User(req.body)
	// 				console.log(new_user)
	// 				new_user.save()
	// 					.then(() => {
	// 						session.user = new_user
	// 						res.json(user)
	// 					})
	// 					.catch(err => {
	// 						console.log('error', err)
	// 						res.status(500).json(err)
	// 					})
	// 			}
	// 		})
	// // }
	// showOne: (req, res) => {
	// 	Question.findById({_id: req.params.id})
	// 		.then(question => res.json(question))
	// },
	// show: (req, res) => {
	// 	Question.find({})
	// 		.then(questions => res.json(questions))
	// 		.catch(err => res.status(500).json(err))
	// },
    create: (req, res) => {
        console.log('hello')
        Question.findById({_id: req.params.id}, (err, question) => {
            if (err) {
                res.status(500).json(err)
            } else {
				let answer = new Answer(req.body)
				answer.save()
                console.log(answer)
                question.answers.push(answer)
                console.log(question)
				question.save()
					.then(() => res.json(question))
					.catch(err => res.status(500).json(err))
            }
        })
	},
	update: (req, res) => {
		console.log('hello')
	}
}
