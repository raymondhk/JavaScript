import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { QaService } from '../qa.service';

@Component({
  selector: 'app-answer',
  templateUrl: './answer.component.html',
  styleUrls: ['./answer.component.css']
})
export class AnswerComponent implements OnInit {
  id;
  question;
  err;
  user_name;
  a = {
    answer: '',
    details: '',
    name: '',
    likes: 0
  };
  constructor(
    private _qa: QaService,
    private _router: Router,
    private _route: ActivatedRoute
  ) {
    this._route.paramMap.subscribe( params => {
      this.id = params.get('id');
      // console.log(this.id);
    });
  }

  ngOnInit() {
    this._qa.showQ(this.id).subscribe(
      (question) => {
        // console.log(question);
        this.question = question.json();
        console.log(this.question);
      },
      (err) => {
        this.err = err;
      }
    );
  }

  create() {
    this._qa.getUserSubject().subscribe(
      (user) => this.user_name = user.name,
      (err) => this.err = err
    );
    this.a.name = this.user_name;
    console.log(this.a);
    this._qa.addA(this.a, this.id)
      .then(() => this._router.navigate(['/']))
      .catch(err => this.err = err);
  }

  logOut() {
    this._qa.logOut();
  }

}
