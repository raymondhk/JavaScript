import { Component, OnInit } from '@angular/core';
import { QaService } from '../qa.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  user = {
    name: '',
    questions: []
  };
  err;
  questions;
  search;
  constructor(
    private _qa: QaService,
    private _router: Router
  ) {
    this._qa.showQuestions().subscribe(
      (questions) => {
        this.questions = questions.json();
      },
      (err) => {
        this.err = err;
      }
    );
  }

  ngOnInit() {
    this.isUser();
  }

  isUser() {
    this._qa.getUserSubject().subscribe(
      (user) => {
        if (!user) {
          this._router.navigate(['/index']);
        } else {
          this.user = user;
          console.log(this.user);
        }
      },
      (err) => console.log('error')
    );
  }

  logOut() {
    this._qa.logOut();
  }
}
