import { Component, OnInit } from '@angular/core';
import { QaService } from '../qa.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user = {
    name: '',
    questions: []
  };
  err;

  constructor(
    private _qa: QaService,
    private _router: Router
  ) { }

  ngOnInit() {
  }

  onSubmit() {
    console.log(this.user);
    this._qa.logIn(this.user, this.logIn.bind(this), this.userError.bind(this));
  }

  logIn() {
    this._router.navigate(['/']);
  }

  userError(err) {
    console.log(err._body);
    this.err = JSON.parse(err._body);
  }

}
