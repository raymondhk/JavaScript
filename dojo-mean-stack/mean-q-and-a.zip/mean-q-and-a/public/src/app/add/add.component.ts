import { Component, OnInit } from '@angular/core';
import { QaService } from '../qa.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  user = {
    name: '',
    questions: [],
  };
  q = {
    question: '',
    description: '',
    answers: [],
  };
  err;
  constructor(
    private _qa: QaService,
    private _router: Router
  ) { }

  ngOnInit() {
    // this.isUser();
  }

  create() {
    console.log(this.q);
    this._qa.createQ(this.q)
      .then(() => this._router.navigate(['/']))
      .catch((err) => this.err = err);
  }

  route() {
    this._router.navigate(['/']);
  }

  userError(err) {
    console.log(err._body);
    this.err = JSON.parse(err._body);
  }



  // isUser() {
  //   this._qa.getUserSubject().subscribe(
  //     (user) => {
  //       if (!user) {
  //         this._router.navigate(['/']);
  //       } else {
  //         this.user = user;
  //         console.log(this.user);
  //       }
  //     },
  //     (err) => console.log('error')
  //   );
  // }

  logOut() {
    this._qa.logOut();
  }
}
