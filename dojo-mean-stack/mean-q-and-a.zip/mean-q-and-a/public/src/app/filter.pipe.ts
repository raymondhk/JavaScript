import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(items: Array<any>, search_text: string): Array<any> {
    if (!search_text) { return items; }

    search_text = search_text.toLowerCase();

    return items.filter(item => item.make.toLowerCase().includes(search_text) || item.model.toLowerCase().includes(search_text));
  }

}
