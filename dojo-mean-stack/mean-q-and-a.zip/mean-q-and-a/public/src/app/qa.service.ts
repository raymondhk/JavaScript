import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class QaService {
  userSubject = new BehaviorSubject(null);

  constructor(
    private _http: Http
  ) { }

  createQ(question) {
    return this._http.post('/api/questions', question)
      .map((data) => data.json())
      .toPromise();
  }
  logIn(user, cb, error) {
    console.log(user);
    return this._http.post('/api/users', user)
    .map((response: Response) => response.json())
    .subscribe(
      (res) => {
        this.userSubject.next(res);
        cb();
      },
      (err) => {
        console.log(err);
        this.userSubject.next(null);
        error(err);
      }
  );
  }

  addA(answer, id) {
    return this._http.post(`/api/answers/${id}`, answer)
      .map((data) => data.json())
      .toPromise();
  }

  showQ(id) {
    console.log(id);
    console.log('hi');
    return this._http.get(`/api/questions/${id}`);
  }

  showQuestions() {
    return this._http.get('/api/questions');
  }

  like(id, answer) {
    console.log(id);
    console.log(answer);
    return this._http.post(`/api/questions/${id}`, answer);
  }

  getUserSubject() {
    console.log(this.userSubject);
    return this.userSubject;
  }

  logOut() {
    this.userSubject.next(null);
    return this.userSubject;
  }
}
