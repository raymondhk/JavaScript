import { Component, OnInit } from '@angular/core';
import { QaService } from '../qa.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css']
})
export class QuestionComponent implements OnInit {
  id;
  question;
  err;
  constructor(
    private _qa: QaService,
    private _router: Router,
    private _route: ActivatedRoute
  ) {
    this._route.paramMap.subscribe( params => {
      this.id = params.get('id');
      // console.log(this.id);
    });
  }

  ngOnInit() {
    this._qa.showQ(this.id).subscribe(
      (question) => {
        this.question = question.json();
        console.log(this.question);
      },
      (err) => {
        console.log(err);
        this.err = err;
      }
    );

    console.log(this.question);
  }

  like(answer, index) {
    answer.likes++;
    answer.ind = index;
    console.log(answer);
    this._qa.like(this.id, answer).subscribe(
      (question) => {
        this.question = question.json();
        console.log(this.question);
      },
      (err) => {
        console.log(err);
        this.err = err;
      }
    );
  }

  logOut() {
    this._qa.logOut();
  }
}
