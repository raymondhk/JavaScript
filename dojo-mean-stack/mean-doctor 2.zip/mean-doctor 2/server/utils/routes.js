const users = require('./../controllers/users.js');
const {resolve} = require('path');
module.exports = function (app) {
	//Set up routes
	// Index route
	app.post('/api/users', users.login);
	app.post('/api/users/:id', users.addAppt);

	app.get('/api/users', users.getAppt);

	app.delete('/api/users/:id', users.deleteAppt);

	app.all("*", (req, res, next) => {
		res.sendfile(resolve("./public/index.html"));
	})

};
