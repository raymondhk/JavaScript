'use strict';
const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const validators = require('mongoose-validators');

const UserSchema = new mongoose.Schema({
	name: { type: String, required: [true, 'Please enter a name!'], minlength: [2, 'Name must be at least 2 characters long!']},
	appointments: []
}, { timestamps: true })

const AppointmentSchema = new mongoose.Schema({
	userId: {type: String },
	name: { type: String },
	date: { type: Date, validate: validators.isAfter() },
	time: { type: String },
	complaint: { type: String, required: [true, 'Please enter your complaint'] }
})
const User = mongoose.model('User', UserSchema)
const Appointment = mongoose.model('Appointment', AppointmentSchema)
