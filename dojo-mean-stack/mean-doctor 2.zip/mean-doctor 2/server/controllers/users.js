const mongoose = require('mongoose');
const User = mongoose.model('User');
const Appointment = mongoose.model('Appointment');
const session = require('express-session');

module.exports = {

	login: (req, res) => {
		User.findOne({name: req.body.name})
			.then(user => {
				if(user){
					session.user = user
					console.log(session.user)
					res.json(user)
				} else {
					let new_user = new User(req.body)
					console.log(new_user)
					new_user.save()
						.then(() => {
							session.user = new_user
							res.json(new_user)
						})
						.catch(err => {
							console.log('error', err)
							res.status(500).json(err)
						})
				}
			})
	},
	addAppt: (req, res) => {
		let flag = false;
		User.findOne({_id: req.params.id})
			.then(user => {
				if(user) {
					let appt = new Appointment(req.body)
					appt.userId = user._id
					appt.name = user.name
					appt.save((err)=>{
						if(err){
							console.log(err)
							res.status(400).json(err)
						}
					})
					user.appointments.push(appt);
					user.save()
						.then(() => res.json(user))
						.catch(err => {
							console.log(err)
							res.status(500).json(err)
						})

				}
			})
	},
	getAppt: (req, res) => {
		Appointment.find({})
			.then(appt => res.json(appt))
			.catch(err => res.status(500).json(err))
	},

	deleteAppt: (req, res) => {
		Appointment.findByIdAndRemove(req.params.id, (err,data) => {
			if(err){
				console.log(err)
				res.status(500).json(err)
			} else {
				console.log(data)
				res.json(data)
			}
		})
	}
}

