import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-appt',
  templateUrl: './appt.component.html',
  styleUrls: ['./appt.component.css']
})
export class ApptComponent implements OnInit {
  appt = {
    date: Date,
    time: Date,
    complaint: ''
  };
  currentUser;
  err = {
    errors: { date: null}
  };

  constructor(
    private _user: UserService,
    private _router: Router
  ) { }

  ngOnInit() {
    this.isUser();
  }

  logOut() {
    console.log('hi');
    this._user.logOut();
  }

  isUser() {
    this._user.getUserSubject().subscribe(
      (user) => {
        if (user) {
          this.currentUser = user;
        } else {
          this._router.navigate(['/']);
        }
      },
      (err) => console.log('error')
    );
  }

  addAppt() {
    console.log(this.appt);
    console.log(this.currentUser._id);
    this._user.addAppt(this.currentUser._id, this.appt)
    .then(() => this._router.navigate(['/']))
    .catch((err) => {
      console.log(err.json());
      this.err = err.json();
    });
  }

}
