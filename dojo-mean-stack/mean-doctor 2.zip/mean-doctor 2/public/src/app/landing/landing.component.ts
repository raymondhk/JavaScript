import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})
export class LandingComponent implements OnInit {
  currentUser;

  constructor(
    private _user: UserService,
    private _router: Router
  ) { }

  ngOnInit() {
    this.isUser();
  }

  isUser() {
    this._user.getUserSubject().subscribe(
      (user) => {
        if (user) {
          this.currentUser = true;
        } else {
          this.currentUser = false;
        }
      },
      (err) => console.log('error')
    );
  }

}
