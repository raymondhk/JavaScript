import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user = {
    name: '',
    appointments: []
  };
  err;

  constructor(
    private _user: UserService,
    private _router: Router
  ) { }

  ngOnInit() {
    this.isUser();
  }

  onSubmit() {
    // console.log(this.user);
    this._user.logIn(this.user, this.isUser.bind(this), this.userError.bind(this));
  }

  isUser() {
    this._user.getUserSubject().subscribe(
      (user) => {
        if (user) {
          // this._router.navigate(['']);
        }
      },
      (err) => console.log('error')
    );
  }

  userError(err) {
    console.log(err._body);
    this.err = JSON.parse(err._body);
  }

}
