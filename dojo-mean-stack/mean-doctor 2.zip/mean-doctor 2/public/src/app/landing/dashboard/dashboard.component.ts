import { Component, OnInit } from '@angular/core';
import { UserService } from '../../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  user;
  appts = [];
  err;
  search;
  constructor(
    private _user: UserService,
    private _router: Router
  ) { }

  ngOnInit() {
    this.isUser();
    this.getAppt();
  }

  isUser() {
    this._user.getUserSubject().subscribe(
      (user) => {
        if (user) {
          this.user = user;
        }
      },
      (err) => console.log('error')
    );
  }

  getAppt() {
    this._user.getAppt().subscribe(
      (appt) => {
        console.log(appt);
        this.appts = appt.json();
        console.log(this.appts);
      },
      (err) => this.err = err
    );
  }

  cancelAppt(id) {
    this._user.deleteAppt(id, this.getAppt.bind(this), this.error.bind(this));
  }

  error(err) {
    this.err = err;
  }

  logOut() {
    console.log('hi');
    this._user.logOut();
  }

  route() {
    this._router.navigate(['/']);
  }

}
