import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class UserService {
  userSubject = new BehaviorSubject(null);

  constructor(
    private _http: Http
  ) { }

  logIn(user, cb, error) {
    // console.log(user);
    return this._http.post('/api/users', user)
    .map((response: Response) => response.json())
    .subscribe(
      (res) => {
        // console.log(res);
        this.userSubject.next(res);
        cb();
      },
      (err) => {
        console.log(err);
        this.userSubject.next(null);
        error(err);
      }
  );
  }

  getUserSubject() {
    // console.log(this.userSubject);
    return this.userSubject;
  }

  logOut() {
    this.userSubject.next(null);
  }

  addAppt(id, appt) {
    return this._http.post(`/api/users/${id}`, appt)
      .map((response: Response) => response.json())
      .toPromise();
  }

  deleteAppt(id, cb, error) {
    return this._http.delete(`/api/users/${id}`)
      .map((response: Response) => response.json())
      .subscribe(
        (res) => {
          console.log(res);
          cb();
        },
        (err) => {
          console.log(err);
          error(err);
        }
      )
  }

  getAppt() {
    return this._http.get('/api/users');
  }
}
